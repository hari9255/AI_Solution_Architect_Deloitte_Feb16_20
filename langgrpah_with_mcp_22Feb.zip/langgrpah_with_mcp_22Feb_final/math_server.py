from fastmcp import FastMCP
from langchain_tavily import TavilySearch
from dotenv import load_dotenv
import os
os.environ["TAVILY_API_KEY"] = "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"

search_tool = TavilySearch(max_results=3)
mcp = FastMCP("MCP_Server")

@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers"""
    print("add tool calling")
    return a + b

@mcp.tool()
def multiply(a: int, b: int) -> int:
    """Multiply two numbers"""
    print("add tool calling")
    return a * b

@mcp.tool()
def search(query: str) -> str:
    """
    Search the internet.
    """
    try:
        print("add tool calling")
        return str(search_tool.invoke(query))
    except Exception as e:
        return f"Search Error: {str(e)}"

if __name__ == "__main__":
    # Explicitly run as an SSE server on port 8000
    mcp.run(transport="sse", port=8000)