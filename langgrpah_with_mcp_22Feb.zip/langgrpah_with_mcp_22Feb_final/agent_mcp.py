import asyncio
import sys
from langchain.agents import create_agent
from langchain_groq import ChatGroq
from langchain.tools import tool
from langchain.messages import SystemMessage, HumanMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
import os
os.environ["GROQ_API_KEY"] = "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"

from dotenv import load_dotenv
load_dotenv()

# Example configuration for an HTTP-based remote server
client = MultiServerMCPClient({
    "MCP_Server": {
        "transport": "sse",
        "url": "http://localhost:8000/sse", # Connects to the running fastmcp server
    }
})

async def setup_tools():
    tools = await client.get_tools()
    return tools

# --- FIX START ---
async def main():
    llm = ChatGroq(model="openai/gpt-oss-120b", temperature=0)
    
    # 1. Await the tools here to get the list instead of a coroutine
    tool_list = await setup_tools()
    
    agent = create_agent(llm, tools=tool_list)

    # 2. Use 'ainvoke' (async invoke) because we are inside an async function
    result = await agent.ainvoke(
        {
            "messages": [
                SystemMessage("You are a helpful assistant that that answers the question and can use tool 'search' to search web for queries , 'add' to perform addtion and 'multiply' to perform multiplication. DO NOT guess and if you're not sure, then tell the user that you don't have data for that query"),
                HumanMessage("what is addtion of 3 and 13")
            ]
        }
    )

    print(result['messages'][-1].content)

if __name__ == "__main__":
    asyncio.run(main())
# --- FIX END ---